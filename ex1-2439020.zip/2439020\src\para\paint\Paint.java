/*
  課題3 KEVIN 24B39020
*/

package para.paint;

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.canvas.*;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.scene.image.WritableImage;
import javafx.scene.image.Image;
import java.util.Stack;

/**
 * JavaFX お絵描きアプリケーションのメインクラス
 */
public class Paint extends Application {
  /** 描画領域 */
  Canvas canvas;
  /** 描画領域のGraphicsContext */
  GraphicsContext gc;
  /** 直前のポインタのx座標 */
  double oldx;
  /** 直前のポインタのy座標 */
  double oldy;
  /** 描画領域の大きさ */
  final int SIZE = 600;
  /** 全消去ボタン */
  Button clear;
  Button rotateL;
  Button rotateR;
  Button undo;

  Stack<WritableImage> history = new Stack<>();

  /**
   * お絵描きプログラムの準備をして、ウィンドウを開きます
   */
  public void start(Stage stage) {
    Group group = new Group();
    canvas = new Canvas(SIZE, SIZE);
    gc = canvas.getGraphicsContext2D();
    drawShapes(gc);

    canvas.setOnMousePressed(ev -> {
      oldx = ev.getX();
      oldy = ev.getY();

      WritableImage snapshot = new WritableImage(SIZE, SIZE);
      canvas.snapshot(null, snapshot);
      history.push(snapshot);
    });

    canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED,
        new EventHandler<MouseEvent>() {
          public void handle(MouseEvent ev) {
            gc.strokeLine(oldx, oldy, ev.getX(), ev.getY());
            oldx = ev.getX();
            oldy = ev.getY();
          }
        });
    clear = new Button("clear");
    clear.setOnAction(e -> {
      gc.setFill(Color.WHITE);
      gc.fillRect(0, 0, SIZE, SIZE);
    });

    undo = new Button("Undo");
    undo.setOnAction(e -> {
      if (!history.isEmpty()) {

        double angle = canvas.getRotate();
        canvas.setRotate(0);

        WritableImage img = history.pop();

        gc.clearRect(0, 0, SIZE, SIZE);
        gc.drawImage(img, 0, 0);

        canvas.setRotate(angle);
      }
    });
    rotateL = new Button("rotate left");
    rotateL.setOnAction(e -> {
      canvas.setRotate((canvas.getRotate() - 90) % 360);
    });

    rotateR = new Button("rotate right");
    rotateR.setOnAction(e -> {
      canvas.setRotate((canvas.getRotate() + 90) % 360);
    });

    BorderPane bp = new BorderPane();
    VBox vb = new VBox();
    HBox hb = new HBox();
    hb.setAlignment(Pos.CENTER);
    HBox hb2 = new HBox();
    hb2.setAlignment(Pos.CENTER);
    Slider sliderr = new Slider(0, 255, 0);
    Slider sliderg = new Slider(0, 255, 0);
    Slider sliderb = new Slider(0, 255, 1);
    Slider slider_transpaSlider = new Slider(0, 1, 1);
    Slider slider_pen_width = new Slider(1, 30, 4);

    Rectangle colorBox = new Rectangle(20, 20);
    colorBox.setStroke(Color.BLACK);
    colorBox.setFill(Color.BLACK);

    ChangeListener<Number> listener = (obs, oldVal, newVal) -> {
      Color currentColor = Color.rgb(
          (int) sliderr.getValue(),
          (int) sliderg.getValue(),
          (int) sliderb.getValue(),
          slider_transpaSlider.getValue()

      );
      gc.setStroke(currentColor);
      gc.setLineWidth((int) slider_pen_width.getValue());

      colorBox.setFill(currentColor);
    };
    sliderr.valueProperty().addListener(listener);
    sliderg.valueProperty().addListener(listener);
    sliderb.valueProperty().addListener(listener);
    slider_transpaSlider.valueProperty().addListener(listener);
    slider_pen_width.valueProperty().addListener(listener);

    vb.setAlignment(Pos.CENTER);
    vb.getChildren().add(sliderr);
    vb.getChildren().add(sliderg);
    vb.getChildren().add(sliderb);
    vb.getChildren().add(slider_transpaSlider);
    vb.getChildren().add(slider_pen_width);
    hb.getChildren().addAll(clear, colorBox);
    hb2.getChildren().addAll(rotateL, rotateR, undo);
    vb.getChildren().add(hb);
    vb.getChildren().add(hb2);
    bp.setTop(vb);
    bp.setCenter(canvas);
    Scene scene = new Scene(bp);
    stage.setScene(scene);
    stage.setTitle("JavaFX Draw");
    stage.show();
  }

  /**
   * 初期化メソッド、startメソッドの呼び出され方とは異なる呼び出され方をする。必要ならば定義する
   */
  public void init() {
  }

  /**
   * 図形を描きます。
   * 図形描画の実装サンプルです
   */
  private void drawShapes(GraphicsContext gc) {
    gc.setFill(Color.WHITE);
    gc.fillRect(0, 0, SIZE, SIZE);
    gc.setFill(Color.GREEN);
    gc.setStroke(Color.BLUE);
    gc.setLineWidth(4);
    gc.strokeLine(40, 10, 10, 40);
    gc.fillOval(60, 10, 30, 30);
    gc.strokeOval(110, 10, 30, 30);
    gc.fillRoundRect(160, 10, 30, 30, 10, 10);
  }
}
